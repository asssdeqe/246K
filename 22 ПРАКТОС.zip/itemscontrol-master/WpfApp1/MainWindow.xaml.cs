﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Product> products = new ObservableCollection<Product>();
        Product selectedProduct = new Product();

        public MainWindow()
        {
            InitializeComponent();

            products.Add(new Product{ Name = "Товар 1", Count = 1, 
                Description = "Офигенный товар 1", Price = 123, Rating = 4, Cover = @"/images/vgpek.png"});

            products.Add(new Product
            {
                Name = "Товар 2",
                Count = 64,
                Description = "Офигенный товар 2",
                Price = 1243,
                Rating = 5,
                Cover = @"/images/cat1.png"
            });

            products.Add(new Product
            {
                Name = "Товар 3",
                Count = 346,
                Description = "Офигенный товар 3",
                Price = 12533,
                Rating = 2,
                Cover = @"/images/cat2.png"
            });

            products.Add(new Product
            {
                Name = "Товар 4",
                Count = 3,
                Description = "Офигенный товар 4",
                Price = 1287,
                Rating = 5,
                Cover = @"/images/chel.png"
            });

            products.Add(new Product
            {
                Name = "Товар 5",
                Count = 87,
                Description = "Офигенный товар 5",
                Price = 19,
                Rating = 1,
                Cover = @"/images/cat2.png"
            });

            ProductList.ItemsSource = products;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            products.Add(new Product
            {
                Name = txtName.Text,
                Count = Convert.ToInt32(txtCount.Text),
                Description = txtDesc.Text,
                Price = Convert.ToInt32(txtPrice.Text),
                Rating = Convert.ToInt32(txtRating.Text),
                Cover = txtImage.Text
            });
        }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if ((sender as StackPanel).DataContext is Product p)
            {
                txtName.Text = p.Name;
                txtCount.Text = p.Count.ToString();
                txtDesc.Text = p.Description;
                txtImage.Text = p.Cover;
                txtPrice.Text = p.Price.ToString();
                txtRating.Text = p.Rating.ToString();

                selectedProduct = p;
            }
        }

        private void StackPanel_MouseEnter(object sender, MouseEventArgs e)
        {
            StackPanel sp = (StackPanel)sender;
            sp.Background = Brushes.Beige;
        }

        private void StackPanel_MouseLeave(object sender, MouseEventArgs e)
        {
            StackPanel sp = (StackPanel)sender;
            sp.Background = Brushes.GreenYellow;
        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult r = MessageBox.Show(
                $"Вы точно хотите удалить {selectedProduct.Name} ?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (r == MessageBoxResult.Yes)
            {
                products.Remove(selectedProduct);
                txtName.Clear();
            }
        }

        private void Sell_Click(object sender, RoutedEventArgs e)
        {
            selectedProduct.Count -= 1;
        }
    }
}