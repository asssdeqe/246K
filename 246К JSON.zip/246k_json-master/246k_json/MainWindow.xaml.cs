﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _246k_json
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Student> students = new ObservableCollection<Student>();

        public MainWindow()
        {
            InitializeComponent();

            tableStudent.ItemsSource = students;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            string json = JsonSerializer.Serialize(
                    students,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true,
                        Encoder = JavaScriptEncoder.Create(UnicodeRanges.All)
                    });

            File.WriteAllText("students.json", json);
            MessageBox.Show("Данные сохранены!");

        }

        private void Load_Click(object sender, RoutedEventArgs e)
        {
            string json = File.ReadAllText("students.json");

            students = JsonSerializer.Deserialize<ObservableCollection<Student>>(json);
            tableStudent.ItemsSource = students;
        }
    }
}