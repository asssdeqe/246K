﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _246k_json
{
    public class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }

}
