﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _246k_json
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
